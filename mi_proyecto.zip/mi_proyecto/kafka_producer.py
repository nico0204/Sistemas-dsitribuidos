from kafka import KafkaProducer
import json

# Configura el productor de Kafka
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')  # Serialización de JSON
)

# Abre el archivo JSON
with open('waze_data.json', 'r') as file:
    data = json.load(file)  # Cargar los datos de waze_data.json

    # Envía cada mensaje al topic 'waze_topic'
    for entry in data:
        producer.send('waze_topic', entry)

producer.flush()  # Asegúrate de que todos los mensajes se envíen
producer.close()  # Cierra el productor
