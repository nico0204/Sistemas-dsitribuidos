from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col

# Inicializar Spark con configuración para Elasticsearch
spark = SparkSession.builder \
    .appName("KafkaToElasticsearch") \
    .config("spark.es.nodes", "localhost") \
    .config("spark.es.port", "9200") \
    .getOrCreate()

# Leer los datos desde Kafka
kafka_data = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "waze_topic") \
    .load()

# Convertir el valor de Kafka de formato binario a string
kafka_data = kafka_data.selectExpr("CAST(value AS STRING)")

# Definir el esquema del JSON que estamos recibiendo
schema = "alert_id INT, city STRING, country STRING, latitude DOUBLE, longitude DOUBLE"

# Parsear el JSON
parsed_data = kafka_data.select(from_json(col("value"), schema).alias("data"))

# Seleccionar las columnas de interés
final_data = parsed_data.select("data.alert_id", "data.city", "data.country", "data.latitude", "data.longitude")

# Guardar los datos en Elasticsearch
final_data.writeStream \
    .format("org.elasticsearch.spark.sql") \
    .option("es.nodes", "localhost") \
    .option("es.index.auto.create", "true") \
    .option("es.resource", "waze_alerts") \
    .outputMode("append") \
    .start().awaitTermination()
