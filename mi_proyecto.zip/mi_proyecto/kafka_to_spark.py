from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# Crear la sesión de Spark
spark = SparkSession.builder \
    .appName("KafkaToSpark") \
    .getOrCreate()

# Configurar la fuente Kafka
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "your_topic") \
    .load()

# Decodificar los datos
df = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")

# Escribir el resultado en consola para ver la salida
query = df.writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

query.awaitTermination()
