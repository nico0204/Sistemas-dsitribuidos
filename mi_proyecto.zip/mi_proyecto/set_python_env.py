import os

# Establecer la ruta correcta de Python en Windows
os.environ['PYSPARK_PYTHON'] = 'C:/Users/Ecomsur/AppData/Local/Programs/Python/Python311/python.exe'
