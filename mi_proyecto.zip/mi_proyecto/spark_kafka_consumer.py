from kafka import KafkaConsumer
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
import json

# Inicializar SparkSession
spark = SparkSession.builder \
    .appName("KafkaToSpark") \
    .config("spark.cassandra.connection.host", "localhost") \
    .getOrCreate()

# Configuración de Kafka Consumer
consumer = KafkaConsumer(
    'waze_topic',            # Nombre del tópico
    bootstrap_servers='localhost:9092',  # Dirección de Kafka
    auto_offset_reset='earliest',  # Leer desde el principio si es la primera vez
    group_id='spark_group'        # ID de grupo
)

# Definir el esquema para los mensajes JSON
schema = "alert_id INT, city STRING, country STRING, latitude DOUBLE, longitude DOUBLE"

# Leer los mensajes de Kafka e insertarlos en Spark
for message in consumer:
    # Decodificar el mensaje de Kafka (en formato binario a JSON)
    message_value = json.loads(message.value.decode('utf-8'))
    
    # Convertir el mensaje en un DataFrame de Spark
    df = spark.read.json(spark.sparkContext.parallelize([message_value]), schema=schema)
    
    # Realizar el procesamiento en Spark
    df.show()  # Aquí puedes agregar las transformaciones que necesites

    # Si quieres realizar alguna operación más, como guardar en Cassandra o Elasticsearch,
    # puedes agregar esas líneas aquí, por ejemplo:
    # df.write.format("org.apache.spark.sql.cassandra").options(table="your_table", keyspace="your_keyspace").save()

# Detener el consumer al finalizar
consumer.close()
