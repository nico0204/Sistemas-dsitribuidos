import json
from kafka import KafkaProducer

# JSON con los datos de las alertas
json_data = '''{
    "alerts": [
        {
            "country": "CI",
            "city": "Lo Espejo",
            "location": {"x": -70.696624, "y": -33.534972}
        },
        {
            "country": "CI",
            "city": "La Cisterna",
            "location": {"x": -70.664526, "y": -33.533209}
        },
        {
            "country": "CI",
            "city": "La Cisterna",
            "location": {"x": -70.667899, "y": -33.545834}
        }
    ]
}'''

# Cargar los datos JSON
data = json.loads(json_data)

# Extraer las alertas (en este caso, las tres primeras)
alerts = data['alerts'][:3]  # Limitar a las primeras tres alertas

# Configurar el productor de Kafka
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',  # Dirección de tu Kafka
    value_serializer=lambda v: json.dumps(v).encode('utf-8')  # Serializa el mensaje como JSON
)

# Recorrer las alertas y enviarlas a Kafka
for i, alert in enumerate(alerts, 1):
    # Extraer la información de la alerta
    location = alert['location']
    lat = location['y']  # latitud
    lon = location['x']  # longitud

    # Crear el mensaje a enviar a Kafka
    message = {
        "alert_id": i,
        "city": alert['city'],
        "country": alert['country'],
        "latitude": lat,
        "longitude": lon
    }
    
    # Enviar el mensaje al topic 'waze_topic'
    producer.send('waze_topic', message)
    
    # Mostrar el mensaje que se envía
    print(f"Sent to Kafka: {message}")
    
# Cerrar el productor después de enviar todos los mensajes
producer.close()
