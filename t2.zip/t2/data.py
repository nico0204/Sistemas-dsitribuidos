import matplotlib.pyplot as plt
from elasticsearch import Elasticsearch
import numpy as np
import pandas as pd

# Connect to Elasticsearch
es = Elasticsearch("http://localhost:9200")


def get_all_metrics(index):
    query = {"query": {"match_all": {}}}

    data = es.search(index=index, body=query, scroll="2m", size=1000)
    sid = data["_scroll_id"]
    scroll_size = len(data["hits"]["hits"])

    all_hits = data["hits"]["hits"]

    while scroll_size > 0:
        data = es.scroll(scroll_id=sid, scroll="2m")
        sid = data["_scroll_id"]
        scroll_size = len(data["hits"]["hits"])
        all_hits.extend(data["hits"]["hits"])

    return all_hits


metrics = get_all_metrics("time")

service_data = {}

for hit in metrics:
    source = hit["_source"]
    service = source["service"]
    processing_time = source["processing_time"]

    if service not in service_data:
        service_data[service] = []

    service_data[service].append(processing_time)


def remove_outliers(data):
    q1 = np.percentile(data, 25)
    q3 = np.percentile(data, 75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    return [x for x in data if lower_bound <= x <= upper_bound]


for service in service_data:
    service_data[service] = remove_outliers(service_data[service])

data_to_plot = [values for values in service_data.values()]
labels = [service for service in service_data.keys()]

plt.figure(figsize=(10, 5))
plt.boxplot(data_to_plot, labels=labels)
plt.xlabel("Service")
plt.ylabel("Processing Time")
plt.title("Processing Time Distribution by Service")
plt.grid(True)
plt.show()

table_data = {"Service": [], "Average": [], "Std": [], "Max": [], "Min": []}

for service, values in service_data.items():
    table_data["Service"].append(service)
    table_data["Average"].append(np.mean(values))
    table_data["Std"].append(np.std(values))
    table_data["Max"].append(np.max(values))
    table_data["Min"].append(np.min(values))

df = pd.DataFrame(table_data)
print(df)
