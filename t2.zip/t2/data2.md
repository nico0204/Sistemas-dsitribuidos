100 workers

                Service   Average       Std       Max       Min
0         order_service  0.000194  0.000132  0.000597  0.000048
1       metrics_service  0.002522  0.000605  0.004312  0.001595
2  notification_service  0.001432  0.000160  0.001889  0.001007

50 workers

                Service   Average       Std       Max       Min
0         order_service  0.000200  0.000146  0.000612  0.000061
1       metrics_service  0.002314  0.000392  0.003449  0.001597
2  notification_service  0.001433  0.000163  0.001880  0.001020


20 workers

                Service   Average       Std       Max       Min
0         order_service  0.000116  0.000030  0.000214  0.000067
1       metrics_service  0.001954  0.000161  0.002420  0.001672
2  notification_service  0.001395  0.000205  0.001995  0.000896

10 workers

                Service   Average       Std       Max       Min
0         order_service  0.000151  0.000041  0.000278  0.000074
1       metrics_service  0.003195  0.000703  0.005253  0.001865
2  notification_service  0.001679  0.000328  0.002561  0.000998

5 workers

                Service   Average      Std       Max       Min
0         order_service  0.000163  0.00005  0.000305  0.000069
1       metrics_service  0.002715  0.00054  0.004349  0.001801
2  notification_service  0.001910  0.00054  0.003512  0.001005

1 worker
                Service   Average       Std       Max       Min
0         order_service  0.000270  0.000191  0.000769  0.000077
1       metrics_service  0.004675  0.001936  0.010469  0.001751
2  notification_service  0.003616  0.002102  0.009652  0.000998