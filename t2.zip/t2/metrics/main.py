from kafka import KafkaConsumer
from elasticsearch import Elasticsearch
import json
import time


class MetricsService:
    def __init__(self):
        self.consumer = KafkaConsumer("metrics", bootstrap_servers="kafka:9092")
        self.es = Elasticsearch("http://elasticsearch:9200")

    def process_orders(self):
        for message in self.consumer:
            start_time = time.time()
            perfomance_data = json.loads(message.value.decode("utf-8"))
            # Aquí se pueden calcular las métricas y almacenarlas en Elasticsearch
            self.es.index(index="time", body=perfomance_data)

            finish_time = time.time()
            self.store_self_metric(finish_time - start_time)

    def store_self_metric(self, t):
        perfomance_data = {
            "service": "metrics_service",
            "processing_time": t,
        }
        # Aquí se pueden calcular las métricas y almacenarlas en Elasticsearch
        self.es.index(index="time", body=perfomance_data)


if __name__ == "__main__":
    service = MetricsService()
    service.process_orders()
