import smtplib
import json
import kafka
from kafka import KafkaConsumer, KafkaProducer
import time


class NotificationService:
    def __init__(self):
        self.consumer = KafkaConsumer("order_update", bootstrap_servers="kafka:9092")
        self.producer = KafkaProducer(bootstrap_servers="kafka:9092")

    def send_email(self, recipient, subject, body):
        # Configurar SMTP
        with smtplib.SMTP("mailserver", 1025) as server:
            # server.starttls()
            server.login("your_email@example.com", "password")
            message = f"Subject: {subject}\n\n{body}"
            server.sendmail("your_email@example.com", recipient, message)
            print(f"Email sent to {recipient}")

    def process_orders(self):
        for message in self.consumer:
            start_time = time.time()
            order_data = json.loads(message.value.decode("utf-8"))
            email_subject = "Order Update"
            email_body = (
                f"Your order for {order_data['product_name']} has been received."
            )
            self.send_email(order_data["customer_email"], email_subject, email_body)

            finish_time = time.time()
            duration = finish_time - start_time
            metrics_data = {
                "service": "notification_service",
                "processing_time": duration,
            }
            self.producer.send("metrics", json.dumps(metrics_data).encode("utf-8"))


if __name__ == "__main__":
    service = NotificationService()
    service.process_orders()
