from concurrent import futures
import grpc
import order_pb2_grpc
import order_pb2
import kafka
import time
import json


class OrderService(order_pb2_grpc.OrderServiceServicer):
    def __init__(self):
        self.kafka_producer = kafka.KafkaProducer(bootstrap_servers="kafka:9092")
        self.metrics_producer = kafka.KafkaProducer(bootstrap_servers="kafka:9092")

    def CreateOrder(self, request, context):
        start_time = time.time()

        order = {
            "product_name": request.product_name,
            "price": request.price,
            "payment_gateway": request.payment_gateway,
            "card_brand": request.card_brand,
            "bank": request.bank,
            "shipping_address": request.shipping_address,
            "shipping_region": request.shipping_region,
            "customer_email": request.customer_email,
            "status": "Processing",
        }

        print(f"Creating order: {order}")

        self.kafka_producer.send("new_order", json.dumps(order).encode("utf-8"))

        finish_time = time.time()
        duration = finish_time - start_time
        metrics_data = {
            "service": "order_service",
            "processing_time": duration,
        }
        self.metrics_producer.send("metrics", json.dumps(metrics_data).encode("utf-8"))

        return order_pb2.OrderResponse(status="Order created")

    def UpdateOrderStatus(self, request, context):
        start_time = time.time()

        update = {
            "product_name": request.product_name,
            "price": request.price,
            "payment_gateway": request.payment_gateway,
            "card_brand": request.card_brand,
            "bank": request.bank,
            "shipping_address": request.shipping_address,
            "shipping_region": request.shipping_region,
            "customer_email": request.customer_email,
            "status": request.new_status,
        }

        self.kafka_producer.send("order_update", json.dumps(update).encode("utf-8"))

        print(f"Updating Order to status: {request.new_status}")

        finish_time = time.time()
        duration = finish_time - start_time
        metrics_data = {
            "service": "order_service",
            "processing_time": duration,
        }
        self.metrics_producer.send("metrics", json.dumps(metrics_data).encode("utf-8"))

        return order_pb2.OrderResponse(status="Order status updated")


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=1))
    order_pb2_grpc.add_OrderServiceServicer_to_server(OrderService(), server)
    server.add_insecure_port("[::]:50051")
    server.start()
    server.wait_for_termination()


if __name__ == "__main__":
    serve()
