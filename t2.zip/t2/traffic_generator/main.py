import grpc
import time
import random
import order_pb2_grpc
import order_pb2
from concurrent.futures import ThreadPoolExecutor


# Establece el canal gRPC
def create_grpc_channel():
    return grpc.insecure_channel("order_management:50051")


class Order:
    states = ["Procesando", "Preparación", "Enviado", "Entregado", "Finalizado"]

    product_name = ""
    price = 0.0
    payment_gateway = ""
    card_brand = ""
    bank = ""
    shipping_address = ""
    shipping_region = ""
    customer_email = ""
    status = ""

    def __init__(
        self,
        product_name,
        price,
        payment_gateway,
        card_brand,
        bank,
        shipping_address,
        shipping_region,
        customer_email,
    ):
        self.product_name = product_name
        self.price = price
        self.payment_gateway = payment_gateway
        self.card_brand = card_brand
        self.bank = bank
        self.shipping_address = shipping_address
        self.shipping_region = shipping_region
        self.customer_email = customer_email
        self.status = "Procesando"

    def next_state(self):
        self.status = Order.states[(Order.states.index(self.status) + 1)]

    def is_finalizado(self):
        return self.status == "Finalizado"


def new_order():
    return Order(
        product_name=random.choice(["Laptop", "Smartphone", "Tablet", "Headphones"]),
        price=round(random.uniform(10000, 1500), 2),
        payment_gateway=random.choice(["MercadoPago", "Webpay", "EtPay", "Kiphu"]),
        card_brand=random.choice(["VISA", "Mastercard", "AMEX"]),
        bank=random.choice(["Bank A", "Bank B", "Bank C"]),
        shipping_address=f"Street {random.randint(1, 10000000)}, City",
        shipping_region=f"Region {random.randint(2, 9)}",
        customer_email=f"customer{random.randint(1, 10000000)}@example.com",
    )


# Crea un pedido
def create_order(stub, order):
    order_request = order_pb2.OrderRequest(
        product_name=order.product_name,
        price=order.price,
        payment_gateway=order.payment_gateway,
        card_brand=order.card_brand,
        bank=order.bank,
        shipping_address=order.shipping_address,
        shipping_region=order.shipping_region,
        customer_email=order.customer_email,
    )

    response = stub.CreateOrder(order_request)
    print(f"Order Created: {response.status}")
    return response.status


# Cambia el estado de un pedido (simulado)
def update_order_status(stub, order):
    # Simulamos estados
    request = order_pb2.UpdateOrderStatusRequest(
        product_name=order.product_name,
        price=order.price,
        payment_gateway=order.payment_gateway,
        card_brand=order.card_brand,
        bank=order.bank,
        shipping_address=order.shipping_address,
        shipping_region=order.shipping_region,
        customer_email=order.customer_email,
        new_status=order.status,
    )

    response = stub.UpdateOrderStatus(request)

    print(f"Order Status Updated: {response.status}")

    return response.status


workers = 100


def send_events():
    with grpc.insecure_channel("order_management:50051") as channel:
        for i in range(int(100 / workers)):
            order = new_order()

            stub = order_pb2_grpc.OrderServiceStub(channel)
            create_order(stub, order)

            time.sleep(random.randint(2, 9) / 100)

            order.next_state()
            update_order_status(stub, order)

            time.sleep(random.randint(2, 9) / 100)

            order.next_state()
            update_order_status(stub, order)

            time.sleep(random.randint(2, 9) / 100)
            order.next_state()
            update_order_status(stub, order)

            time.sleep(random.randint(2, 9) / 100)

            order.next_state()
            update_order_status(stub, order)

            time.sleep(random.randint(2, 9) / 100)


def main():
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(send_events) for _ in range(int(workers))]
        for future in futures:
            future.result()


if __name__ == "__main__":
    main()
